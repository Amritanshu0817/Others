/*
    Author: Arijit Paria 
    Subscribe @tutoriex on youtube to get more such scripts
    Note:
    This script is free to use, do not pay anyone anything.
    To modify or redistribute, kindly follow the license agreement strictly.
*/

chrome.devtools.panels.create('TUTORIEX', null, 'panel.html', null);
console.log("This is devtools script!")