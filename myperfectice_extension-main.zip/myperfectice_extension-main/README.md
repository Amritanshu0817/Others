# MyPerfectice Extension
An Extension to automate MyPerfectice Tests.

## NOTE: 
1. This extension is only for educational purposes. 
2. The author(s), contributor(s) and/or any person linked with its creation or updation here in this repository is not responsible for any harm or consequences due to its personal use by the user.
3. If the platform (myperfectise) personally demands us to remove this extension for valid reasons, we are ready to listen to them.

## License in a glimpse
![Screenshot_20221220_221232](https://user-images.githubusercontent.com/71935307/208720531-9df7560b-e9be-411c-a324-a5b6556e1bf4.png)
